#define PACKAGE "csv2latex"
#define RELEASE_DATE "2009/03/11"
#define VERSION "0.13"

